# Chrome Move Tab

## Commands

| Key            | Suggested Keyboard shortcut |
|:---------------|:----------------------------|
| move-tab-right | Ctrl+Shift+Left             |
| move-tab-left  | Ctrl+Shift+Right            |
| move-tab-start | Ctrl+Shift+Up               |
| move-tab-end   | Ctrl+Shift+Down             |
